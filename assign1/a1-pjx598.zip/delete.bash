#!/bin/bash

# Example input
# 
# ESL English as a Second Language
# Literacy in a Second Language
# MWF 8/26/19 12/13/19
# 3
# 52

read -p "Enter an course department code and number:" dept_code course_number

if [ ! -r ./data/${dept_code^^}${course_number^^}.crs ]; then
  echo "Error: course not found"
fi
if [ -r ./data/${dept_code^^}${course_number^^}.crs ]; then 
  read dept_code dept_name
  read course_name
  read course_shed course_startDate course_endDate
  read course_hours
  read course_size
  
rm -r ./data/${dept_code^^}${course_number^^}.crs

echo "`date "+%Y-%m-%d %H:%M:%S"` DELETED: $dept_code $course_number $course_name" >> ./data/queries.log
echo "$course_number was successfully deleted."
fi < ./data/${dept_code^^}${course_number^^}.crs
