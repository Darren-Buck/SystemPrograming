#!/bin/bash
read -p "Department code: " dept_code
read -p "Department name: " dept_name
read -p "Course Number: " course_number

if [ ! -r ./data/${dept_code^^}$course_number.crs ]; then
  read -p "Course Name: " course_name
  read -p "Course Schedule: " course_shed
  read -p "Course Start date: " course_startDate
  read -p "Course End Date: " course_endDate
  read -p "Course Credit Hours: " course_hours
  read -p "Initial Course Enrollment: " course_size
  echo "$dept_code $dept_name
    $course_name 
    $course_shed $course_startDate $course_endDate
    $course_hours
    $course_size" > ./data/${dept_code^^}$course_number.crs
  
  echo "'date "+%Y-%m-%d %H:%M:%S"' CREATED: $dept_code $course_number $course_name" >> ./data/queries.log
else
  echo "Error: course already exists"
fi
