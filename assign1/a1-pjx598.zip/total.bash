#!/bin/bash

echo "Total course records: "
find data -name "*.crs" | wc -l
