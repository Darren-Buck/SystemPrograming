#!/bin/bash

# Example input
# 
# ESL English as a Second Language
# Literacy in a Second Language
# MWF 8/26/19 12/13/19
# 3
# 52
read -p "Department code:" dept_code
read -p "Course Number:" course_number

if [ ! -r ./data/${dept_code^^}$course_number.crs ]; then
    echo "ERROR: course not found"
    exit 1
  fi
    
read -p "Department name:" dept_name
read -p "Course Name:" course_name
read -p "Course Schedule:" course_shed
read -p "Course Start date:" course_startDate
read -p "Course End Date:" course_endDate
read -p "Course Credit Hours:" course_hours
read -p "Initial Course Enrollment:" course_size

if [ -r ./data/${dept_code^^}$course_number.crs ]; then
  read dept_code_original dept_name_original
  read course_name_original
  read course_shed_original course_startDate_original course_endDate_original
  read course_hours_original
  read course_size_original
    
    if [ ! "$dept_name" ]; then
        dept_name=$dept_name_original
    fi
    
    if [ ! "$course_name" ]; then
        course_name=$course_name_original
    fi
    if [ ! "$course_shed" ]; then
        course_shed=$course_shed_original
    fi
    if [ ! "$course_startDate" ]; then
        course_startDate=$course_startDate_original
    fi
    if [ ! "$course_endDate" ]; then
        course_endDate=$course_endDate_original
    fi
    if [ ! "$course_hours" ]; then
        course_hours=$course_hours_original
    fi
    if [ ! "$course_size" ]; then
        course_size=$ccourse_size_original
    fi
echo "$dept_code $dept_name
$course_name 
$course_shed $course_startDate $course_endDate
$corse_hours
$course_size" > ./data/${dept_code^^}$course_number.crs
echo "'date "+%Y-%m-%d %H:%M:%S"' Updated: $dept_code $course_number $course_name" >> ./data/queries.log
fi < ./data/${dept_code^^}$course_number.crs