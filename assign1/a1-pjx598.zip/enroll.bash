#!/bin/bash

# Example input
# 
# ESL English as a Second Language
# Literacy in a Second Language
# MWF 8/26/19 12/13/19
# 3
# 52

read -p "Enter an course department code and number:" dept_code course_number
dept_code=${dept_code^^}
course_number=$course_number


if [ ! -r ./data/${dept_code}${course_number}.crs ]; then
  echo "Error: course not found"
fi
read -p "Enter an enrollment change amount:" change_amt
if [ -r ./data/${dept_code}${course_number}.crs ]; then 
  read dept_code dept_name
  read course_name
  read course_shed course_startDate course_endDate
  read course_hours
  read course_size_original

    course_size=$(($course_size_original + $change_amt))
    course_size_original=$ccourse_size
    
echo "$dept_code $dept_name
$course_name 
$course_shed $course_startDate $course_endDate
$corse_hours
$course_size" > ./data/${dept_code^^}$course_number.crs
  echo "'date "+%Y-%m-%d %H:%M:%S"' ENROLLMENT: $dept_code $course_number $course_name changed by $change_amt" >> ./data/queries.log
  fi < ./data/${dept_code}${course_number}.crs