#!/bin/bash
read -p "Enter a department code and course number: " dept_code course_number
dept_code=${dept_code^^}
course_number=$course_number

if [ ! -r ./data/${dept_code^^}$course_number.crs ]; then
    echo "ERROR: course not found"
    exit 1
fi 
if [ -r ./data/${dept_code}${course_number}.crs ]; then
  read dept_code dept_name
  read course_name
  read course_shed course_startDate course_endDate
  read course_hours
  read course_size
  
  echo "Course department: $dept_code $dept_name"
  echo "Course number: $course_number"
  echo "Course name: $course_name"
  echo "Scheduled days: $course_shed"
  echo "Course start: $course_startDate"
  echo "Course end: $course_endDate"
  echo "Credit hours: $course_hours"
  echo "Enrolled Students: $course_size"

fi < ./data/${dept_code}${course_number}.crs