#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdbool.h>
#include <sys/wait.h>
#define BUFSIZE 4096   

char buffer[BUFSIZE]; 
FILE *datafile = NULL;
// if fopen failes return false or return EXIT_FAILURE=1
bool wordcount(const char * fileName){

		  char *token;
		  const char delim[]= " \t\n\r";
		  int count = 0; 

		  datafile = fopen(fileName, "r");
		  memset(buffer,0,BUFSIZE);
		  while(fgets(buffer,BUFSIZE, datafile)){
					 if(strtok(buffer,delim)){
                count++;
								while (strtok(NULL,delim) != NULL){
										  count ++;
								}
            token = NULL;
            memset(buffer,0,BUFSIZE);
					 }
			}		 
           printf("Child process for %s: word count is %d\n", fileName,count);

					 return true;// or EXIT_SUCCESS =0
}
/*----------------------------------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------------------------------*/
int main (int argc, char ** argv) {

		  long lForkPid;        // PID of child
		  int iExitStatus;  // Used by parent to get status of child
		  long lWaitPid;        // PID of child that terminated

		  int totalfiles = (argc -1);
		  int success = 0;
		  int i;
		  int count = 0; 
		  for (i=1; i<=argc; i++){

					 // create a child process
					 lForkPid= fork();
					 // Both the parent and first child continue here
					 switch(lForkPid) {
								case -1:
										  errExit("fork failed: %s\n", strerror(errno));
										  break;
								case 0: // child process
										  return !wordcount(argv[i]); // bool true = 1 exis statuse failure = 1 and vice vers
										  break;
								default: // parent process - the writer
										  break;
					 }
		  }    
		  // make parrent wait for all children to close count the number of successful closes 

		  //while(wait(&iExitStatNULLus) != -1)

		  while(wait(&iExitStatus) != -1) {
					 if(WIFEXITED(iExitStatus) && WEXITSTATUS(iExitStatus) == 0) {
								success += 1;
					 }
		  }
        printf("%d of %d files counted successfully.\n",success,totalfiles);	
        return 0;
}
